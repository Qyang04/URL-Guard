package com.example.virus_detection_application;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private EditText urlInput;
    private TextView scanResult;
    private UrlSafetyService service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.txtAmount);
        scanResult = findViewById(R.id.scan_result);
        Button scanButton = findViewById(R.id.button);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://www.virustotal.com/api/v3/") // VirusTotal API base URL for version 2
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        service = retrofit.create(UrlSafetyService.class);

        scanButton.setOnClickListener(v -> {
            String url = urlInput.getText().toString().trim();
            if (!url.isEmpty()) {
                scanUrl(url);
            } else {
                scanResult.setText("Please enter a valid URL.");
            }
        });
    }

    private void scanUrl(String url) {
        Call<UrlScanResult> call = service.scanUrl("4c6c6e545f2ef1bcd1cb0dac27984ee059ca55c41a9f0653c3c723b54119b2c6", url);
        call.enqueue(new Callback<UrlScanResult>() {
            @Override
            public void onResponse(Call<UrlScanResult> call, Response<UrlScanResult> response) {
                if (response.isSuccessful() && response.body() != null) {
                    UrlScanResult result = response.body();
                    StringBuilder resultMessage = new StringBuilder();
                    if (result.getResponseCode() == 1) { // Assuming 1 means success
                        resultMessage.append("URL: ").append(url).append("\n");
                        resultMessage.append("Positives: ").append(result.getPositives()).append("\n");
                        resultMessage.append("Total Scans: ").append(result.getTotal()).append("\n");

                        if (result.getPositives() > 0) {
                            resultMessage.append("The URL is not safe.\n");
                        } else {
                            resultMessage.append("The URL is safe.\n");
                        }
                    } else {
                        resultMessage.append("Failed to check the URL.\n");
                    }
                    resultMessage.append("Message: ").append(result.getVerboseMsg());

                    scanResult.setText(resultMessage.toString());
                } else {
                    scanResult.setText("Failed to check the URL. Message: " + response.message());
                }
            }
            @Override
            public void onFailure(Call<UrlScanResult> call, Throwable t) {
                scanResult.setText("Error: " + t.getMessage());
            }
        });
    }
}